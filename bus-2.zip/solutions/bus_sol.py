n = int(input())  
numbers = list(map(int, input().split()))  
for i in range(n):
    if numbers[i] <= 437:
        print(f"Crash {i + 1}")
        exit()
print("No crash")