#include <iostream>
using namespace std;
int main()
{
    int n, c = 1;
    cin >> n;
    bool flag = 0;
    for (int i = 0; i < n; i++)
    {   
        int now;
        cin >> now;
        if (now <= 437)
        {
            cout << "Crash ";
            cout << c;
            return 0;
        }
        c++;
    }
    cout << "No crash";
    return 0;
}