#include "testlib.h"
using namespace std;
int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    cout << n << "\n";
    for (int i = 0; i < n; ++i)
    {
        if (i != n - 1) 
        {   
            cout << rnd.next(1, 10000) << " ";
        }
        else
        {
            cout << rnd.next(1, 10000) << "\n";
        }
    }
}