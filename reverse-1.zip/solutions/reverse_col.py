n = int(input())
v = list(map(int, input().split()))
print(' '.join(map(str, reversed(v))))