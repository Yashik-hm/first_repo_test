#include <iostream>
#include <vector>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<int> even, odd;
    for(int i = 1; i <= n; ++i){
        int now;
        cin >> now;
        if(now % 2 == 0){
            even.push_back(now);
        } else{
            odd.push_back(now);
        }
    }

    for(int i = 0; i < odd.size(); ++i){
        cout << odd[i] << " ";
    }
    if (odd.size())
    {
        cout << "\n";
    }
    for(int i = 0; i < even.size(); ++i)
    {
        cout << even[i] << " ";
    }
    if (even.size())
    {
        cout << "\n";
    }
    
    if(even.size() >= odd.size())
    {
        cout << "YES";
    } else 
    {
        cout << "NO";
    }
    
    return 0;
}