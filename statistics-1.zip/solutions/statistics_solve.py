n = int(input())  
numbers = list(map(int, input().split()))  
even = []
odd = []

for num in numbers:
    if num % 2 == 0: even.append(num)
    else: odd.append(num)


if odd: print(' '.join(map(str, odd)))
if even: print(' '.join(map(str, even)))
print("YES" if len(even) >= len(odd) else "NO")