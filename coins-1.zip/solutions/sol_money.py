n = int(input())
count_0 = count_1 = 0
for i in range(n):
    tmp = int(input())
    if(tmp) : count_1 += 1
    else : count_0 += 1
if (count_0 > count_1) : print(count_1)
else : print(count_0)
