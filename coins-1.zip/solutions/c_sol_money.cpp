#include <iostream>
using namespace std;
int main()
{
    int n, count_1 = 0, count_0 = 0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {   
        int now;
        cin >> now;
        count_0 += now == 0;
        count_1 += now == 1;
    }
    cout << n - ((count_0 > count_1) ?  count_0 : count_1);
    return 0;
}